var exitBlock : GameObject;
var victorySound : AudioClip;

function OnTriggerEnter(other : Collider) {
    if( other.gameObject.name == 'Player' ){
    	AudioSource.PlayClipAtPoint(victorySound, transform.position);
    	exitBlock.active = true;
    }
}
