var spikeBalls : GameObject[];

function OnTriggerEnter(other : Collider){
	if( other.name == 'Player' ){
		for( var ball in spikeBalls ){
			ball.rigidbody.useGravity = true;
		}
	}
}
