private var worldRotationScript;
var deathSound : AudioClip;

private var gameStatus;

function Awake(){
	gameStatus = GameObject.Find('Game').GetComponent('Status');
	//worldRotationScript = GameObject.Find('World').GetComponent('WorldRotate');
}

function OnCollisionEnter (other : Collision){
	if( other.gameObject.name == 'Player' ){
		AudioSource.PlayClipAtPoint(deathSound, transform.position);
		yield WaitForSeconds (0.05);
		
		gameStatus.Death();
	}
}