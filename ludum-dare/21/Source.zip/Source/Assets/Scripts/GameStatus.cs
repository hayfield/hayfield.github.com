// http://www.unifycommunity.com/wiki/index.php?title=Singleton
/*using UnityEngine;
using System.Collections;

public class GameStatus : MonoBehaviour
{
    private static GameStatus instance;
    
    public static GameStatus Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new GameObject("GameStatus").AddComponent<GameStatus> ();
            }

            return instance;
        }
    }
    
    public void OnApplicationQuit(){
        instance = null;
    }
	
	// own code here
	public GameObject gameCamera;
	public GameObject[] rooms;
	
	private int currentRoom;
	private WorldRotate worldRotationScript;
	private GameObject room;
	private RoomSetup roomStatus;
	private GameObject player;
	private CameraPositioner cameraPositioner;
	
	void Awake(){
		worldRotationScript = GameObject.Find("World").GetComponent<WorldRotate>();
		player = GameObject.Find("Player");
		currentRoom = 0;
		cameraPositioner = gameCamera.GetComponent<CameraPositioner>();
		DontDestroyOnLoad(gameObject);
		PositionCamera(currentRoom, true);
	}
	
	void AdvanceRoom(){
		currentRoom++;
		Debug.Log("advanced room");
		PositionCamera(currentRoom, false);
	}
	
	void PositionCamera(int roomID, bool quickly){
		Debug.Log("positioning camera");
		room = rooms[roomID];
		roomStatus = room.GetComponent<RoomSetup>();
		cameraPositioner.MoveToPosition(roomStatus.GetCameraPos(), quickly);
	}
	
	void ResetCurrentRoom(){
		Debug.Log("restting room");
		LoadRoom(currentRoom, true);
	}
	
	void InitCurrentRoom(){
		Debug.Log("restting room");
		LoadRoom(currentRoom, false);
	}
	
	void LoadRoom(int ID, bool loadLevel){
		room = rooms[ID];
		roomStatus = room.GetComponent<RoomSetup>();
		Debug.Log(currentRoom);
		if( loadLevel ){
			Application.LoadLevel(Application.loadedLevel);
		} else {
			Debug.Log(currentRoom);
			worldRotationScript.SetRotationZ( roomStatus.GetDefaultRotation() );
			Debug.Log(roomStatus.GetCameraPos());
			worldRotationScript.UpdateRotation();
			gameCamera.transform.position = roomStatus.GetCameraPos();
			player.transform.position = roomStatus.GetPlayerStartPos();
			Debug.Log(roomStatus.GetPlayerStartPos());
		}
	}
}*/
