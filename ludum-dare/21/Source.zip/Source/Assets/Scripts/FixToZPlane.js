private var zPosition : float;

function Awake(){
	zPosition = transform.position.z;
}

function FixedUpdate(){
	transform.position.z = zPosition;
}
