var nextRoom : int = 1;

private var gameStatus;

function Awake(){
	gameStatus = GameObject.Find('Game').GetComponent('Status');
}

function OnTriggerEnter(other : Collider){
	if( gameStatus.GetCurrentRoom() < nextRoom && other.gameObject.name == 'Player' ){
		gameStatus.AdvanceRoom();
	}
}
