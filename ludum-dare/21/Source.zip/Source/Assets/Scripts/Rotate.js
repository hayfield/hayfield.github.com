var speed : float = 100;

function Update(){
	transform.Rotate( 0, 0, speed * Time.deltaTime );
}
