var texture1 : Material;
var texture2 : Material;
var period : float = 1f;

InvokeRepeating( 'ChangeTexture', period, period );

function ChangeTexture(){
	if( renderer.sharedMaterial == texture1 ){
		renderer.sharedMaterial = texture2;
	} else {
		renderer.sharedMaterial = texture1;
	}
}
