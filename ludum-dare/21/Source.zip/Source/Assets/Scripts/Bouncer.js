var force = 30;
var bounceSound : AudioClip;

function OnCollisionEnter (other : Collision){
	var angle = -transform.eulerAngles.z * Mathf.Deg2Rad;
	other.gameObject.rigidbody.AddForce(force * Mathf.Sin(angle), force * Mathf.Cos(angle), 0, ForceMode.Impulse);
	AudioSource.PlayClipAtPoint(bounceSound, transform.position);
}
