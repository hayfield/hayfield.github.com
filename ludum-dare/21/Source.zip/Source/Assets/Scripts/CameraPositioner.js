private var currentPositionID : int;
private var movementTime : float = 0.5;
private var startPos : Vector3;
private var endPos : Vector3;
private var startTime;
private var moving : boolean;
private var gameStatus;

function Awake(){
	currentPositionID = 0;
	moving = false;
}

function Start(){
	// make sure things are in the right place after Application.LoadLevel()
	gameStatus = GameObject.Find('Game').GetComponent('Status');
	gameStatus.InitCurrentRoom();
}

function Update(){
	if( moving ){
		if( Time.time - startTime > movementTime ){
			moving = false;
		}
		transform.position = Vector3.Lerp(startPos, endPos, (1 / movementTime) * (Time.time - startTime));
	}
}

function MoveToPosition(pos : Vector3, quickly : boolean){
	if( quickly ){
		transform.position = pos;
	} else {
		startPos = transform.position;
		endPos = pos + gameStatus.GetCameraOffset();
		currentPositionID++;
		startTime = Time.time;
		moving = true;
	}
}
