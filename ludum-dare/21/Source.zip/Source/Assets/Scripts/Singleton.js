function Awake(){
	var statuses = GameObject.FindGameObjectsWithTag('GameStatus');
	for( var status in statuses ){
		var statusScript = status.GetComponent('Status');
		try {
			var bob = statusScript.GetGameCamera().name;
		} catch(err){
			// destroy any extra game status trackers
			Destroy( status );
		}
	}
}
