var speed = 60.0;

//var minimumX:float = -60.0F;
//var maximumX:float = 60.0F;
var minimumZ:float = -60.0F;
var maximumZ:float = 60.0F;

//static var rotationX:float = 0F;
static var rotationZ:float = 0F;

private var previousRotation : float;
private var centreOfRotation : Vector3;

function FixedUpdate(){
	previousRotation = rotationZ;
	//rotationX += Input.GetAxis('Vertical') * Time.deltaTime * speed;
	//rotationX = Mathf.Clamp (rotationX, minimumX, maximumX);
	rotationZ += Input.GetAxis('Horizontal') * Time.deltaTime * speed;
	rotationZ = Mathf.Clamp (rotationZ, minimumZ, maximumZ);
	
	UpdateRotation();
}

function UpdateRotation(){
	transform.RotateAround(centreOfRotation, Vector3.forward, previousRotation - rotationZ);
	// transform.localEulerAngles = new Vector3(0, 0, -rotationZ);
}

function SetRotationZ(val){
	rotationZ = val;
}

function SetCentreOfRotation(pos){
	centreOfRotation = pos;
}

function SetZRotationLimits(min, max){
	minimumZ = min;
	maximumZ = max;
}
