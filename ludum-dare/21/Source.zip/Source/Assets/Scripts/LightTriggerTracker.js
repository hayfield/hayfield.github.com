var lightTriggers : GameObject[];
var barrier : GameObject;

private var numberOfActiveTriggers : int;

function Awake(){
	numberOfActiveTriggers = 0;
}

function CheckTriggerCount(){
	if( numberOfActiveTriggers == lightTriggers.length ){
		barrier.active = false;
	} else {
		barrier.active = true;
	}
}

function ActivateTrigger(){
	numberOfActiveTriggers++;
	CheckTriggerCount();
}

function DisableTrigger(){
	numberOfActiveTriggers--;
	CheckTriggerCount();
}
