var unlockables : GameObject[];
var pauseBeforeDestruction : float = 1f;
var timeBetweenDestructions : float = 0.5f;
var movables : GameObject[];
var unlockSound : AudioClip;

function OnTriggerEnter(other : Collider){
	if( other.gameObject.name == 'Player' ){
		AudioSource.PlayClipAtPoint(unlockSound, transform.position);
		gameObject.renderer.enabled = false;
		gameObject.collider.enabled = false;
		
		if( unlockables.length > 0 ){
			yield WaitForSeconds( pauseBeforeDestruction );
		
			for( var object in unlockables ){
				Destroy(object);
				
				yield WaitForSeconds( timeBetweenDestructions );
			}
		} else if( movables.length > 0 ){
			for( var wall in movables ){
				var script = wall.GetComponent('MovingWall');
				script.StartMovement();
			}
		}
		
		Destroy(gameObject);
	}
}
