function OnCollisionEnter(other : Collision){
	if( other.gameObject.name == 'Bullet' ){
		Destroy(gameObject);
	}
}

function OnTriggerEnter(other : Collider){
	if( other.gameObject.name.Contains('Bullet') ){
		Destroy(gameObject);
	}
}

