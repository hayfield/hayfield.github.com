var circularShooter : GameObject;

private var shooterScript;
function Awake(){
	shooterScript = circularShooter.GetComponent('CircularBulletSpawner');
}

function OnTriggerEnter(other : Collider) {
    if( other.gameObject.name == 'Player' ){
    	shooterScript.enabled = true;
    }
}

function OnTriggerExit(other : Collider) {
    if( other.gameObject.name == 'Player' ){
    	shooterScript.enabled = false;
    }
}
