// the setup of a room
var cameraPos : Vector3; // where the camera is when viewing the room
var playerStartPos : Vector3; // where the ball starts if resetting
var defaultRotation : float = 0; // how the room should be rotated upon a restart
var centreOfRotation : GameObject; // the object the world will rotate around when in this room
var minZRotation : float = -60f; // the minimum rotation of the room
var maxZRotation : float = 60f; // the maximum rotation of the room

function GetCameraPos(){
	return cameraPos;
}

function GetPlayerStartPos(){
	return playerStartPos;
}

function GetDefaultRotation(){
	return defaultRotation;
}

function GetCentreOfRotation(){
	return centreOfRotation.transform.position;
}

function GetMinZRotation(){
	return minZRotation;
}

function GetMaxZRotation(){
	return maxZRotation;
}

function GetCameraOffset(){
	return centreOfRotation.transform.position - centreOfRotation.transform.localPosition;
}
