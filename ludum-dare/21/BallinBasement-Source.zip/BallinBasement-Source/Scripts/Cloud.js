var fadeTime : float = 1f;

private var fading : boolean;
private var startTime : float;
private var startColor : Color;
private var endColor : Color;

function Awake(){
	fading = false;
	startColor = renderer.material.color;
	endColor = renderer.material.color;
	endColor.a = 0;
	if(fadeTime == 0){
		fadeTime = 0.000001;
	}
}

function OnCollisionEnter(other : Collision){
	if( other.gameObject.name == 'Player' ){
		fading = true;
		startTime = Time.time;
		
		yield WaitForSeconds(fadeTime);
		
		Destroy(gameObject);
	}
}

function Update(){
	if(fading){
		// need to ensure the shader allows transparency
		renderer.material.color = Color.Lerp(startColor, endColor, (1 / fadeTime) * (Time.time - startTime));
	}
}
