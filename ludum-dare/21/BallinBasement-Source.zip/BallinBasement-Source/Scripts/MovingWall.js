// moving platforms move back and forth, walls are a single movement
var movementTime : float = 1f;
var endPosition : Vector3;

private var startPos : Vector3;
private var endPos : Vector3;
private var moving : boolean;
private var startTime;

function Awake(){
	moving = false;
	startPos = transform.localPosition;
	endPos = endPosition;
}

function Update(){
	if( moving ){
		if( Time.time - startTime > movementTime ){
			moving = false;
		}
		transform.localPosition = Vector3.Lerp(startPos, endPos, (1 / movementTime) * (Time.time - startTime));
	}
}

function StartMovement(){
	startTime = Time.time;
	moving = true;
}
