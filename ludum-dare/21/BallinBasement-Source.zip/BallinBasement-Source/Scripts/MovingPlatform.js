// moving platforms move back and forth, walls are a single movement
var speed : float = 1f;
var xPositive : float = 0f;
var xNegative : float = 0f;
var yPositive : float = 0f;
var yNegative : float = 0f;

private var startPos : Vector3;
private var minPos : Vector3;
private var maxPos : Vector3;

function Awake(){
	startPos = transform.localPosition;
	minPos = Vector3( startPos.x - xNegative, startPos.y - yNegative, startPos.z );
	maxPos = Vector3( startPos.x + xPositive, startPos.y + yPositive, startPos.z );
}

function Update(){
	var pos = Mathf.PingPong( Time.time * speed, 1 );
	transform.localPosition = Vector3.Lerp(minPos, maxPos, pos);
}
