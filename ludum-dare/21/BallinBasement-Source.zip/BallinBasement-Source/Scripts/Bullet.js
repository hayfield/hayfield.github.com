var speed : float = 10f;
var deathSound : AudioClip;
var explosion : Transform;
var explosionSound : AudioClip;
private var spawnTime;

private var worldRotationScript;
private var gameStatus;

function Awake(){
	gameStatus = GameObject.Find('Game').GetComponent('Status');
	//worldRotationScript = GameObject.Find('World').GetComponent('WorldRotate');
	spawnTime = Time.time;
}

function Update(){
	transform.localPosition += transform.up * speed * Time.deltaTime;
}

function OnTriggerEnter(other : Collider){
	if( other.name == 'Player' ){
		AudioSource.PlayClipAtPoint(explosionSound, transform.position);
		MakeExplosion();
		yield WaitForSeconds (0.05);
		gameStatus.Death();
		//Application.LoadLevel(Application.loadedLevel);
		//worldRotationScript.rotationZ = 0;
	} else if( other.name != 'RocketBase' && !other.name.Contains('Wall Movement Trigger') ){
		MakeExplosion();
		Destroy(gameObject);
	}
}

function MakeExplosion(){
	Instantiate( explosion, transform.position, transform.rotation );
	AudioSource.PlayClipAtPoint(explosionSound, transform.position);
}
