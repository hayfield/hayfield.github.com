var force = 100;
var boostSound : AudioClip;

function OnTriggerEnter(other : Collider){
	if( other.gameObject.name == 'Player' ){
		AudioSource.PlayClipAtPoint(boostSound, transform.position);
	}
}

function OnTriggerStay(other : Collider){
	if( other.gameObject.name == 'Player' ){
		other.rigidbody.AddForce(force * Time.deltaTime, 0, 0, ForceMode.Impulse);
	}
}
