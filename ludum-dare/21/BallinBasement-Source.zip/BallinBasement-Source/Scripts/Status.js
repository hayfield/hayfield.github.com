// tracks the status of the game
var gameCamera : GameObject;
var rooms : GameObject[];
var currentRoom : int;
var logo : Texture;

private var roomSliderVal;
private var worldRotationScript;
private var room;
private var roomStatus;
private var player;
private var cameraPositioner;
private var paused : boolean;
private var totalDeaths : int;

function Awake(){
	PauseGame();
	worldRotationScript = GameObject.Find('World').GetComponent('WorldRotate');
	player = GameObject.Find('Player');
	currentRoom = PlayerPrefs.GetInt('Current Room');
	totalDeaths = PlayerPrefs.GetInt('Total Deaths');
	roomSliderVal = currentRoom;
	cameraPositioner = gameCamera.GetComponent('CameraPositioner');
	DontDestroyOnLoad(gameObject);
	PositionCamera(currentRoom, true);
}

function AdvanceRoom(){
	currentRoom++;
	roomSliderVal = currentRoom;
	PlayerPrefs.SetInt('Current Room', currentRoom);
	room = rooms[currentRoom];
	roomStatus = room.GetComponent('RoomSetup');
	worldRotationScript.SetCentreOfRotation( roomStatus.GetCentreOfRotation() );
	worldRotationScript.SetZRotationLimits( roomStatus.GetMinZRotation(), roomStatus.GetMaxZRotation() );
	PositionCamera(currentRoom, false);
}

function PositionCamera(roomID : int, quickly : boolean){
	room = rooms[roomID];
	roomStatus = room.GetComponent('RoomSetup');
	cameraPositioner.MoveToPosition(roomStatus.GetCameraPos(), quickly);
}

function Death(){
	totalDeaths++;
	PlayerPrefs.SetInt('Total Deaths', totalDeaths);
	ResetCurrentRoom();
}

function ResetCurrentRoom(){
	LoadRoom(currentRoom, true);
}

function InitCurrentRoom(){
	LoadRoom(currentRoom, false);
}

function LoadRoom(ID : int, loadLevel : boolean){
	room = rooms[ID];
	roomStatus = room.GetComponent('RoomSetup');
	if( loadLevel ){
		Application.LoadLevel(Application.loadedLevel);
	} else {
		worldRotationScript.SetRotationZ( roomStatus.GetDefaultRotation() );
		worldRotationScript.SetCentreOfRotation( roomStatus.GetCentreOfRotation() );
		worldRotationScript.SetZRotationLimits( roomStatus.GetMinZRotation(), roomStatus.GetMaxZRotation() );
		worldRotationScript.UpdateRotation();
		gameCamera.transform.position = roomStatus.GetCameraPos();
		player.transform.position = roomStatus.GetPlayerStartPos();
	}
	UnpauseGame();
}

function GetGameCamera(){
	return gameCamera;
}

function GetCurrentRoom(){
	return currentRoom;
}

function GetCameraOffset(){
	room = rooms[currentRoom];
	roomStatus = room.GetComponent('RoomSetup');
	return roomStatus.GetCameraOffset();
}

function OnGUI(){
	GUI.Label(Rect (10, 10, 100, 20), 'Deaths: ' + PlayerPrefs.GetInt('Total Deaths'));
	if( Input.GetKey('escape') ){
		PauseGame();
	}
	if( paused ){
		// Make a group on the center of the screen
		GUILayout.BeginArea(Rect(Screen.width / 2 - 180, Screen.height / 2 - 180, 512, 256));

		GUILayout.Box(logo);
		GUILayout.Box('Paused');
		GUILayout.BeginVertical();
		if( GUILayout.Button('Continue Game') ){
			UnpauseGame();
		}

		roomSliderVal = GUILayout.HorizontalSlider(roomSliderVal, 0.0, rooms.length - 1);
		if( GUILayout.Button('Play from Room: ' + Mathf.Round(roomSliderVal)) ){
			PlayerPrefs.SetInt('Current Room', Mathf.Round(roomSliderVal));
			currentRoom = Mathf.Round(roomSliderVal);
			ResetCurrentRoom();
			UnpauseGame();
		}
		if( GUILayout.Button('Reset Deaths') ){
			ResetDeaths();
		}
		GUILayout.EndVertical();
		GUILayout.EndArea();
	}
}

function ResetDeaths(){
	totalDeaths = 0;
	PlayerPrefs.SetInt('Total Deaths', totalDeaths);
}

function PauseGame(){
	paused = true;
	Time.timeScale = 0;
}

function UnpauseGame(){
	paused = false;
	Time.timeScale = 1;
}
