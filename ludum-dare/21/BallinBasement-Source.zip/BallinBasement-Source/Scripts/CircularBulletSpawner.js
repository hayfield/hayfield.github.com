var bullet : Transform;
var spawnRate : float = 1f;
var numberOfBullets : int = 5;
var shootingSound : AudioClip;
var rotationOfFirst : float = 0f;

InvokeRepeating('LaunchBullets', 1, spawnRate);

function LaunchBullets(){
	var i = 0;
	var spawn;
	rotation = transform.rotation;
	while( i < numberOfBullets ){
		AudioSource.PlayClipAtPoint(shootingSound, transform.position);
		spawn = Instantiate( bullet, transform.position, transform.rotation );
		spawn.localEulerAngles += Vector3( 0, 0, ((360 / numberOfBullets) * i) + rotationOfFirst );
		spawn.localPosition += spawn.up * spawn.localScale.y * 5;
		
		i++;
	}
}
