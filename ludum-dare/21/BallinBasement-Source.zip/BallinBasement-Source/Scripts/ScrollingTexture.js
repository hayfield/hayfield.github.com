var xSpeed : float = 0f;
var ySpeed : float = 0f;

function FixedUpdate(){
	renderer.material.mainTextureOffset = Vector2(Time.time * xSpeed, Time.time * ySpeed);
}
