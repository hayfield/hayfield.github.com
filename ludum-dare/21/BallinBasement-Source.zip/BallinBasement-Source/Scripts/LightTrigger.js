var newMaterial : Material;
var tracker : GameObject;

private var trackerScript;
private var originalMaterial : Material;
private var spotlight;

function Awake(){
	trackerScript = tracker.GetComponent('LightTriggerTracker');
	originalMaterial = renderer.sharedMaterial;
	for(var child : Transform in transform){
		if( child.gameObject.name == 'Spotlight' ){
			spotlight = child;
		}
	}
}

function OnCollisionEnter(other : Collision){
	if( renderer.sharedMaterial == newMaterial ){
		renderer.sharedMaterial = originalMaterial;
		spotlight.active = false;
		trackerScript.DisableTrigger();
	} else {
		renderer.sharedMaterial = newMaterial;
		spotlight.active = true;
		trackerScript.ActivateTrigger();
	}
}
